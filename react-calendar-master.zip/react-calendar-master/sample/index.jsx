import React from 'react';
import { render } from 'react-dom';
import Sample from './Sample';

render(<Sample />, document.getElementById('react-root'));
